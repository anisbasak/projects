//
//  AppDelegate.h
//  MyChat
//
//  Created by Anis Basak on 02/12/16.
//  Copyright © 2016 Anis Basak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Firebase.h"
#import <GoogleSignIn/GoogleSignIn.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

