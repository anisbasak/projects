//
//  ChatViewController.h
//  MyChat
//
//  Created by Anis Basak on 02/12/16.
//  Copyright © 2016 Anis Basak. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ChatViewController : ViewController

@end
