//
//  Helper.h
//  MyChat
//
//  Created by Anis Basak on 04/12/16.
//  Copyright © 2016 Anis Basak. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <FirebaseAuth/FirebaseAuth.h>
#import "AppDelegate.h"
#import <GoogleSignIn/GoogleSignIn.h>

@interface Helper : NSObject

+ (id)sharedHelper;
- (void)anonymousLogin;
- (void)googleLogin:(GIDAuthentication *)authentication;

@end
