//
//  Helper.m
//  MyChat
//
//  Created by Anis Basak on 04/12/16.
//  Copyright © 2016 Anis Basak. All rights reserved.
//

#import "Helper.h"

@implementation Helper

+ (id)sharedHelper {
    static Helper *sharedHelper = nil;
    @synchronized(self) {
        if (sharedHelper == nil)
            sharedHelper = [[self alloc] init];
    }
    return sharedHelper;
}

- (id)init {
    if (self = [super init]) {
        
    }
    return self;
}

- (void)anonymousLogin {
    
    [[FIRAuth auth] signInAnonymouslyWithCompletion:^(FIRUser *anonymousUser, NSError *error) {
        if (error == nil) {
            NSLog(@"User Id: %@",anonymousUser.uid);
        } else {
            NSLog(@"%@",error.localizedDescription);
            return;
        }
    }];
    
    
    
    
    //switching from login view controller to chat view controller
    
    // create a storyboard object
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    // use the storyboard object to insatanciate a navigation controller
    UIViewController *navigationController = [storyboard instantiateViewControllerWithIdentifier:@"NavigationVC"];
    
    // get the app delegate
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // set navigation controller as the root controller
    appDelegate.window.rootViewController = navigationController;
}

- (void)googleLogin:(GIDAuthentication *)authentication {
    
    FIRAuthCredential *credential = [FIRGoogleAuthProvider credentialWithIDToken:authentication.idToken accessToken:authentication.accessToken];
    
    [[FIRAuth auth] signInWithCredential:credential completion:^(FIRUser *googleUser, NSError *error) {
        if (error == nil) {
            NSLog(@"%@",googleUser.email);
            NSLog(@"%@",googleUser.displayName);
        } else {
            NSLog(@"%@",error.localizedDescription);
            return;
        }
        
        //switching from login view controller to chat view controller
        
        // create a storyboard object
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        // use the storyboard object to insatanciate a navigation controller
        UIViewController *navigationController = [storyboard instantiateViewControllerWithIdentifier:@"NavigationVC"];
        
        // get the app delegate
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        
        // set navigation controller as the root controller
        appDelegate.window.rootViewController = navigationController;
    }];
}


@end
