//
//  ViewController.h
//  MyChat
//
//  Created by Anis Basak on 02/12/16.
//  Copyright © 2016 Anis Basak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <FirebaseAuth/FirebaseAuth.h>
#import "Helper.h"
#import <GoogleSignIn/GoogleSignIn.h>

@interface ViewController : UIViewController <GIDSignInUIDelegate, GIDSignInDelegate>


@end

