//
//  ViewController.m
//  MyChat
//
//  Created by Anis Basak on 02/12/16.
//  Copyright © 2016 Anis Basak. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [GIDSignIn sharedInstance].uiDelegate = (id) self;
    [GIDSignIn sharedInstance].delegate = (id) self;
    [GIDSignIn sharedInstance].clientID = @"866311802920-e2lgai17sdvu60r5a50vm7nj97eimu9n.apps.googleusercontent.com";
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)anonymousButtonDidTapped:(UIButton *)sender {
    
    Helper *myHelper = [Helper sharedHelper];
    [myHelper anonymousLogin];
    
    
}

- (IBAction)googleButtonDidTapped:(id)sender {
    
    [[GIDSignIn sharedInstance] signIn];
    
    
}

- (void)signIn:(GIDSignIn *)signIn didSignInForUser:(GIDGoogleUser *)user withError:(NSError *)error {
    
    NSLog(@"%@",user.authentication);
    Helper *myHelper = [Helper sharedHelper];
    [myHelper googleLogin:user.authentication];
    
}

@end
